Hello friend,

Thank you very much for downloading this texture! We (us) are thrilled that you chose to download it and very much hope that it suits your needs.

If there are any issues with it, please let us (the handsome bastards who run the website you downloaded it from) know so that we can fix it.

There are several ways to get a hold of us, and all of them work well. First, try the contact us form on the top of our webpage, or at: http://gametextures.com/game/index.php/contacts/ .

If you need us for a more urgent matter, our live chat at the bottom of our webpage works well and we would be thrilled to hear from you. 


Now, on to the meat of this Read-Me file.


Your texture download will include the targa image files of the texture you chose to download - the map type naming convention can be found at the end of the file name.

_d = Diffuse map
_s = Specular map
_g = Gloss map
_n = Normal Map
_nY+ = Normal Map with y+ (An inverted green channel, works best with UDK, 3DS Max)
_t = Transparency Map
_h = Height Map
_e = Emissive Map
_p = Only on Decal images, this is the preview image of what the decal looks like on a transparent background.
_r = Reflection Mask, to be used if your scene has a cube-map, or other reflective objects or properties.


_d1, _d2, _d3, etc. =  on more than a handfull of our textures we've been so bold as to include some alternative diffuse maps in different colors and styles. 


As always, 

Stay safe and keep your head down! 



Much Love,


 -- Gametextures.com